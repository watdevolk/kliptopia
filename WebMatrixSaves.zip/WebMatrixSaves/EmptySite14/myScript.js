window.onload= function() {
    //alert("It works");
}